################################################################################
##                                                                            ##  
##            This file is part of the se3-bib Racket module v3.0             ##  
##                Copyright by Leonie Dreschler-Fischer, 2010                 ##
##              Ported to Racket v6.2.1 by Benjamin Seppke, 2015              ##  
##                                                                            ##  
################################################################################

Diese Bibliothek wird zur Vorlesung "Softwareentwicklung 3" der Universität 
Hamburg (Fachbereich Informatik) empfohlen.

Autor: Leonie Dreschler-Fischer
       (überarbeitet von Benjamin Seppke)

Letzte Änderung 29.09.2015: 
Anpassung an DrRacket, Version 6.2.1
Getestet unter Mac OS X 10.10.5, 64-bit
